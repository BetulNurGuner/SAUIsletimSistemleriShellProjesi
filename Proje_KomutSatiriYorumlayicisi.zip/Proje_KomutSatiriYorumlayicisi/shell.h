#define RED   "\x1B[31m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define WHT   "\x1B[37m"
#define BLK   "\x1B[30m"	
#define RESET "\x1B[0m"
#define READ  0
#define WRITE 1


static char* currentDirectory;
 

static char* args[512];
pid_t pid;
int command_pipe[2];


int ChangeDir(char**);

static int command(int, int, int);

static void temizleme(int); 

static int run(char* , int, int, int);
static char line[512];		// bir komut max 512 karakter içerebilir
static int n = 0; /* number of calls to 'command' */

void Prompt();

void KarsilamaEkrani();

static void split(char*);

int Bilgi(char**);

static int run(char* , int , int , int);

static char* skipwhite(char*);		// boşlukla ayrılmış komutları ayıklamak için

void SonKomutCalistir();







