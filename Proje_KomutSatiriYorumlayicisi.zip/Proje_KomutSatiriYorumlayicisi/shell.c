#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
 
#include <sys/types.h>
#include <sys/wait.h>

#include "shell.h"


int ChangeDir(char **args)
{
	if (args[1]==NULL)
	{
		fprintf(stderr,"uyarı: expected argument to \"cd\"\n");
	}
	else
	{
		if (chdir(args[1])!=0)
		{
			perror("hata");
		}
	}
	return 1;
}
 

static int command(int input, int first, int last)
{
	int pipettes[2];
 
	pipe( pipettes );	
	pid = fork();
 
 
	if (pid == 0) {
		if (first == 1 && last == 0 && input == 0) {
			// İlk komut
			dup2( pipettes[WRITE], STDOUT_FILENO );
		} else if (first == 0 && last == 0 && input != 0) {
			// ikinci komut
			dup2(input, STDIN_FILENO);
			dup2(pipettes[WRITE], STDOUT_FILENO);
		} else {
			// Son komut
			dup2( input, STDIN_FILENO );
		}
 
		if (execvp( args[0], args) == -1)
			_exit(EXIT_FAILURE); // Çocuk hata yaparsa
	}
 
	if (input != 0) 
		close(input);
 
	// yazılacak başka bir şey yok
	close(pipettes[WRITE]);
 
	// Eğer son komutsa okunacak başka bir şey yok 
	if (last == 1)
		close(pipettes[READ]);
 
	return pipettes[READ];
}
 
/* Son temizlik yapılmadan önce işlemlerin sona ermesi beklenir.
 *  n : komutun çalıştırılma sayısı
 */
static void temizleme(int n)
{
	int i;
	for (i = 0; i < n; ++i) 
		wait(NULL); 
}
 
 


void Prompt()
{
	char hostn[1204] = "";
	gethostname(hostn, sizeof(hostn));
	printf(MAG "%s@%s:"RESET BLU "%s > " RESET, getenv("LOGNAME"), hostn, getcwd(currentDirectory, 1024));		// prompta o an bulunulan konumu yazdırdık
}

void KarsilamaEkrani(){

	printf( "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		"	SHELL: Merhaba, Komut Satırı Yorumlayıcımıza Hoşgeldiniz.\n\n"
		"	* Çıkış yapmak isterseniz 'quit' yazın ya da 'CTRL-D' ye basın. \n"
		"	* Bu proje hakkında daha fazla bilgi edinmek isterseniz 'bilgi' yazın.\n"
		"	* İyi çalışmalar dileriz. \n"
		"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	
	
}
 
int main()
{
	KarsilamaEkrani();
	while (1) {
		
		Prompt();
		fflush(NULL);
 
		/* komut satırı okunur */
		if (!fgets(line, 512, stdin)) 
			return 0;
 
		SonKomutCalistir();
		
	}
	return 0;
}

void SonKomutCalistir(){
	int input = 0;
	int first = 1;
 
	char* cmd = line;
	char* next = strchr(cmd, ';'); // next değişkeni ile noktalı virgülleri ayırt ettik ilk noktalı virgülü atadık 
 	
 	while (next != NULL) 
	{
		
		*next = '\0';
		input = run(cmd, input, first, 0);
 
		cmd = next + 1;		// noktalı virgülden sonraki komutu işlemek için
		next = strchr(cmd, ';'); /* Bir sonraki ';'ü bul */
		first = 0;
	}
	input = run(cmd, input, first, 1);	
	temizleme(n);
	n = 0;
 	

}

 

int Bilgi(char **args){
	
	printf( "İşletim Sistemleri Proje Ödevidir. \n"
		"Hazırlayanlar: "RED " B181210068 Betül Nur Güner (1A) \n"
		"\t\tB181210011 Rabia Okatan (1A)\n"
		"\t\tB181210026 Gülinsu Özturan (1A)\n"
		"\t\tG181210089 Eyüp Atıcı (2A)\n"
		"\t\tB181210053 Hilal Merve Hancıoğlu (1A)\n"RESET);
		
}


 
static int run(char* cmd, int input, int first, int last)
{
	split(cmd);
	if (args[0] != NULL) {
		if (strcmp(args[0], "quit") == 0) 
			exit(0);
		if (strcmp(args[0],"bilgi")==0)
		{
			Bilgi(args);
			return 1;
		}
		if (strcmp(args[0],"cd")==0)		// komut cd ise 
		{
			ChangeDir(args);		// ChangeDir(args) fonksiyonunu çağırarak konum degiştiriyor
			return 1;
		}	
		n += 1;
		return command(input, first, last);
	}
	return 0;
}
 
static char* skipwhite(char* s)		// boşlukla ayrılmış komutları ayıklamak için
{
	while (isspace(*s)) ++s;
	return s;
}
 
static void split(char* cmd)
{
	cmd = skipwhite(cmd);
	char* next = strchr(cmd, ' ');
	int i = 0;
 
	while(next != NULL) {
		next[0] = '\0';
		args[i] = cmd;
		++i;
		cmd = skipwhite(next + 1);
		next = strchr(cmd, ' ');
	}
 
	if (cmd[0] != '\0') {
		args[i] = cmd;
		next = strchr(cmd, '\n');
		next[0] = '\0';
		++i; 
	}
 
	args[i] = NULL;
}


